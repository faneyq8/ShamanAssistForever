# Changelog

## 0.2.1 Beta 1

- Cross-checked all three rotations against current Wowhead, Icy Veins, WoW Forever DB, SixtySim and community discussions.
- Fire Nova readiness now requires an active Fire Totem, matching its actual rotation requirement.
- Removed the Enhancement off-hand imbue alert because Forever Enhancement officially uses two-handed weapons.
- Added a native Healing Stream Totem timeline for Restoration group-healing uptime.
- Kept Restoration Fire Nova as an optional damage alert because current healing guides use it only when no urgent healing is required.
- Documented why target Flame Shock and ally Riptide durations are not guessed from restricted combat data.

## 0.2.0 Beta 1

- Audited the current WoW Forever 1.60.1 Shaman data.
- Removed Lava Burst, which was replaced by the passive Call of Thunder talent.
- Renamed Elemental Mastery to Lightning Mastery and retained its active-buff timeline.
- Corrected Maelstrom Weapon to the Forever proc aura 408505.
- Replaced the invalid player-aura Riptide tracker with rank-aware cooldown readiness.
- Removed Tidal Waves, which is not part of the current Forever Restoration tree.
- Added Elemental Devastation, Rage of the Farseer, Mana Tide Totem and Fire Nova.
- Added rank-aware cooldown readiness for Stormstrike, Riptide, Nature's Swiftness and Fire Nova.
- Added native Mana Tide totem duration tracking.

## 0.1.1 Beta 1

- Removed automatic talent-tree inference.
- Added a fully manual Elemental, Enhancement, and Restoration selector.
- Enhancement is now the default and existing Auto settings migrate to Enhancement.
- Tree changes apply immediately to gameplay alerts, Test All, and Edit Layout.

## 0.1.0 Beta 1

- First WoW Forever build for client 1.60.1 and interface 16001.
- Added Elemental, Enhancement and Restoration talent-tree alert sets.
- Added automatic tree inference with a manual override for hybrid builds.
- Retained Test All, Edit Layout, timelines, themes, action-button glows and Cooldown Manager support.
- Added a separate saved-variable namespace for side-by-side Retail installation.
