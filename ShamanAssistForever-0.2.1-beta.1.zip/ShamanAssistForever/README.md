# Shaman Assist Forever 0.2.1 Beta 1

Shaman Assist Forever provides movable proc, buff, shield, weapon-imbue and cooldown alerts for Shaman in World of Warcraft: Forever 1.60.1.

## Talent tree support

- Elemental: Elemental Focus / Clearcasting, Elemental Devastation, Lightning Mastery, Fire Nova readiness, Lightning Shield and weapon imbue reminders.
- Enhancement: Maelstrom Weapon, Stormstrike readiness, Flurry, Rage of the Farseer, Fire Nova readiness, Lightning Shield and the two-handed weapon imbue reminder.
- Restoration: Riptide readiness, Nature's Swiftness readiness, Mana Tide and Healing Stream timelines, Fire Nova readiness, Water Shield and weapon imbue reminders.

Fire Nova readiness is shown only while an active Fire Totem is present. Target debuffs such as Flame Shock and ally Riptide are intentionally not inferred when Forever restricts target aura data in combat.

Forever has classic-style talent trees rather than Retail specializations. Select Elemental, Enhancement or Restoration manually in General; Enhancement is the default. Test All and Edit Layout show only the selected tree.

## Commands

- `/shaf` or `/shaforever`: open settings
- `/shaf test`: test every alert for the selected tree
- `/shaf stop`: stop the preview
- `/shaf unlock` / `/shaf lock`: preview, move and save alert positions
- `/shaf rescan`: rescan action buttons and Cooldown Manager
- `/shaf status`: print detection status

## Compatibility

- WoW Forever 1.60.1
- Interface 16001
- Modern Mainline API with Forever combat restrictions
- Separate `ShamanAssistForeverDB`, so it can be installed beside Shaman Assist Retail

This is a beta. Live-game testing is recommended because Forever class tuning and restricted combat data can change between builds.
