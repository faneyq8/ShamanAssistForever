local addonName, addon = ...
ShamanAssistForever = addon
addon.version = "0.2.1-beta.1"
addon.icon = "Interface\\AddOns\\ShamanAssistForever\\Media\\ShamanAssistIcon.tga"

-- Forever keeps the three classic talent trees rather than Retail specializations.
-- These IDs are internal Shaman Assist keys only; auto detection is based on learned
-- signature spells and the player can always select a tree manually.
addon.specNames = {[262]="Elemental",[263]="Enhancement",[264]="Restoration"}
addon.specOrders = {
    [262]={"eleFocus","eleDevastation","eleLightningMastery","eleFireNova","eleLightningShield","eleImbue"},
    [263]={"maelstrom","stormstrike","flurry","rageFarseer","enhFireNova","enhLightningShield","mainHand"},
    [264]={"restoRiptide","restoNatureSwiftness","restoManaTide","restoHealingStream","restoFireNova","restoWaterShield","restoImbue"},
}
addon.order={}
addon.info={
    eleFocus={name="Elemental Focus",aura=16246,icon=16164,spells={403,421,1535},text="CLEARCASTING",kind="proc",spec=262},
    eleDevastation={name="Elemental Devastation",aura=29177,icon=30160,spells={30160},text="ELEMENTAL DEVASTATION",kind="activeBuff",spec=262},
    eleLightningMastery={name="Lightning Mastery",aura=16166,icon=16166,spells={16166},text="LIGHTNING MASTERY",kind="activeBuff",spec=262},
    eleFireNova={name="Fire Nova Ready",icon=1535,spells={11315,11314,8499,8498,1535},requiresTotemSlot=1,text="FIRE NOVA READY",kind="cooldown",spec=262},
    eleLightningShield={name="Lightning Shield",aura=324,icon=324,spells={324},text="LIGHTNING SHIELD MISSING",kind="buff",spec=262},
    eleImbue={name="Main-hand Imbue",icon=8024,spells={8024,8017,8033,8232},slot=16,text="WEAPON IMBUE MISSING",kind="enchant",spec=262},

    maelstrom={name="Maelstrom Weapon",aura=408505,icon=51530,spells={51530,403},text="MAELSTROM READY",kind="stacks",spec=263},
    stormstrike={name="Stormstrike Ready",icon=17364,spells={17364},text="STORMSTRIKE READY",kind="cooldown",spec=263},
    flurry={name="Flurry",aura=16280,icon=16256,spells={17364},text="FLURRY",kind="activeBuff",spec=263},
    rageFarseer={name="Rage of the Farseer",aura=425336,icon=425336,spells={425336},text="RAGE OF THE FARSEER",kind="activeBuff",spec=263},
    enhFireNova={name="Fire Nova Ready",icon=1535,spells={11315,11314,8499,8498,1535},requiresTotemSlot=1,text="FIRE NOVA READY",kind="cooldown",spec=263},
    enhLightningShield={name="Lightning Shield",aura=324,icon=324,spells={324},text="LIGHTNING SHIELD MISSING",kind="buff",spec=263},
    mainHand={name="Main-hand Imbue",icon=8232,spells={8232,8024,8017,8033},slot=16,text="MAIN-HAND IMBUE MISSING",kind="enchant",spec=263},

    restoRiptide={name="Riptide Ready",icon=408521,spells={1239243,1239242,408521},text="RIPTIDE READY",kind="cooldown",spec=264},
    restoNatureSwiftness={name="Nature's Swiftness Ready",icon=16188,spells={16188},text="NATURE'S SWIFTNESS READY",kind="cooldown",spec=264},
    restoManaTide={name="Mana Tide Totem",aura=16190,icon=16190,spells={17360,17359,17354,16190},totemSpells={17360,17359,17354,16190},text="MANA TIDE",kind="activeBuff",spec=264},
    restoHealingStream={name="Healing Stream Totem",aura=5394,icon=5394,spells={10463,10462,6377,6375,5394},totemSpells={10463,10462,6377,6375,5394},text="HEALING STREAM",kind="activeBuff",spec=264},
    restoFireNova={name="Fire Nova Ready",icon=1535,spells={11315,11314,8499,8498,1535},requiresTotemSlot=1,text="FIRE NOVA READY",kind="cooldown",spec=264},
    restoWaterShield={name="Water Shield",aura=52127,icon=52127,spells={52127},text="WATER SHIELD MISSING",kind="buff",spec=264},
    restoImbue={name="Main-hand Imbue",icon=8024,spells={8024,8017,8033,8232},slot=16,text="WEAPON IMBUE MISSING",kind="enchant",spec=264},
}
for _,spec in ipairs({262,263,264}) do
    for _,key in ipairs(addon.specOrders[spec]) do addon.order[#addon.order+1]=key end
end

function addon:IsCurrentAlert(key) return self.info[key] and self.info[key].spec==self.specID end
function addon:GetSelectedSpec()
    local choice=ShamanAssistForeverDB and ShamanAssistForeverDB.specView
    return self.specNames[tonumber(choice)] and tonumber(choice) or 263
end
function addon:IsSelectedAlert(key) return self.info[key] and self.info[key].spec==self:GetSelectedSpec() end
function addon:SetSpecView(choice)
    if not self.specNames[tonumber(choice)] then return end
    if self.layoutEditing then self:FinishLayoutEdit(false) end
    self:StopTest();ShamanAssistForeverDB.specView=choice
    self:UpdateSpec();self:ApplySettings()
    if self.settingsWindow then self.settingsWindow:Refresh() end
end

addon.defaults={enabled=true,locked=true,standaloneTheme="frosted",minimapHidden=false,specView="263",minimapAngle=225,schema=2,alerts={}}
for index,key in ipairs(addon.order) do
    local info=addon.info[key]
    local reminder=info.kind=="buff" or info.kind=="enchant"
    addon.defaults.alerts[key]={enabled=true,iconEnabled=true,textEnabled=false,sound=false,combatOnly=not reminder,
        actionGlow=not reminder,cdmGlow=false,glowType="pixel",color=reminder and {r=1,g=.35,b=.15} or {r=.25,g=.70,b=1},
        alpha=1,speed=.25,lines=8,thickness=2,particles=4,scale=1,size=48,fontSize=23,text=info.text,
        threshold=5,barEnabled=key=="maelstrom",alwaysShow=false,timelineEnabled=info.kind=="activeBuff",
        durationText=true,showStacks=true,timelineWidth=280,timelineHeight=24,
        timelinePoint={"CENTER","CENTER",0,-250-(index%5)*32},point={"CENTER","CENTER",((index-1)%6-2.5)*62,-135},
        textPoint={"CENTER","CENTER",0,180-((index-1)%6)*32}}
    if info.kind=="activeBuff" then addon.defaults.alerts[key].combatOnly=false;addon.defaults.alerts[key].actionGlow=false end
end

-- Retail-only hero trees do not exist in Forever. Keep these hooks so the
-- shared display, buff tracker and settings code stays small and compatible.
addon.heroNames={}
function addon:RegisterHeroAlerts() end
function addon:UpdateHeroSpec() self.heroID=nil end
function addon:IsHeroEligible() return true end
function addon:ReadHeroTotem(info,state)
    if not info.totemSpells or type(GetTotemInfo)~="function" then return false end
    local wanted={}
    for _,id in ipairs(info.totemSpells) do wanted[id]=true end
    for slot=1,4 do
        -- pcall prepends its own success value to GetTotemInfo's eight returns.
        local ok,present,_,start,duration,_,_,_,spellID=pcall(GetTotemInfo,slot)
        present=self:Public(present,"boolean");spellID=self:Public(spellID,"number")
        if ok and present and wanted[spellID] then
            state.active=true;state.status="Totem active"
            state.expiration=(self:Public(start,"number") or 0)+(self:Public(duration,"number") or 0)
            state.totalDuration=self:Public(duration,"number")
            return true
        end
    end
    return false
end
addon.states, addon.overlay, addon.known = {}, {}, {}
for _, key in ipairs(addon.order) do addon.states[key] = { active = false, status = "Not initialized" } end

function addon:IsSecret(value)
    return issecretvalue and issecretvalue(value) or false
end
function addon:Public(value, kind)
    if self:IsSecret(value) then return nil end
    if kind and type(value) ~= kind then return nil end
    return value
end
function addon:SafeCall(fn, ...)
    if type(fn) ~= "function" then return nil, false end
    local ok, value = pcall(fn, ...)
    if not ok or self:IsSecret(value) then return nil, false end
    return value, true
end
local function Merge(target, defaults)
    for key, value in pairs(defaults) do
        if type(value) == "table" then
            if type(target[key]) ~= "table" then target[key] = {} end
            Merge(target[key], value)
        elseif type(target[key]) ~= type(value) then target[key] = value end
    end
end
function addon:InitializeDB()
    if type(ShamanAssistForeverDB) ~= "table" then ShamanAssistForeverDB = {} end
    Merge(ShamanAssistForeverDB, self.defaults)
    -- 0.1.0 used automatic inference. Migrate it to the requested manual
    -- Enhancement default so the selected tree is always deterministic.
    if ShamanAssistForeverDB.specView == "auto" or not self.specNames[tonumber(ShamanAssistForeverDB.specView)] then
        ShamanAssistForeverDB.specView = "263"
    end
    ShamanAssistForeverDB.schema = 2
    for _, settings in pairs(ShamanAssistForeverDB.alerts) do
        if type(settings) == "table" then
            for _, name in ipairs({ "threshold", "size", "fontSize", "alpha", "speed", "lines", "thickness" }) do
                local limits = { threshold={1,10}, size={24,96}, fontSize={12,48}, alpha={0.1,1}, speed={0.05,1}, lines={1,16}, thickness={1,6} }
                local range = limits[name]
                if type(settings[name]) == "number" then settings[name] = math.max(range[1], math.min(range[2], settings[name])) end
            end
        end
    end
end
function addon:UpdateSpec()
    local _,class=UnitClass("player")
    local fn=C_SpellBook and C_SpellBook.IsSpellKnownOrInSpellBook or IsPlayerSpell
    if not InCombatLockdown() then
        for _,info in pairs(self.info) do
            for _,id in ipairs(info.spells) do
                local known=self:SafeCall(fn,id);self.known[id]=known==true
            end
        end
    end
    local selected=class=="SHAMAN" and self:GetSelectedSpec() or nil
    if self.specID~=selected then
        if self.layoutEditing then self:FinishLayoutEdit(false) end
        self.testKey=nil;self.testGeneration=(self.testGeneration or 0)+1;self.overlay={}
    end
    self.specID=selected;self.specName=self.specNames[selected] or "No Shaman tree";self.isSupported=selected~=nil
    self.isEnhancement=selected==263
    if self.settingsWindow then self.settingsWindow:Refresh() end
end
function addon:ReadAura(id)
    local aura, readable = self:SafeCall(C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID, id)
    if not readable then return nil, false end
    -- A nil restricted aura is not proof that a buff is missing in combat.
    if aura == nil then
        local restricted, ok = self:SafeCall(C_Secrets and C_Secrets.ShouldSpellAuraBeSecret, id)
        if ok and type(restricted)=="boolean" then return nil, not restricted end
        return nil, not InCombatLockdown()
    end
    if type(aura) ~= "table" then return nil, false end
    return aura, true
end
function addon:ReadCrashLightningMissing()
    local allReadable = true
    for _, id in ipairs(self.info.crashLightning.auras) do
        local aura, readable = self:ReadAura(id)
        if aura then return false, "Buff present" end
        if not readable then allReadable = false end
    end
    if allReadable then return true, "Buff missing" end
    -- Only actual Tracked Buff items can establish absence. A spell's
    -- cooldown state or an icon's visibility is not a buff-presence signal.
    local readable = false
    for frame, entry in pairs(self.external or {}) do
        if entry.valid and entry.buffSource and entry.keys.crashLightning then
            local active, ok = self:SafeCall(frame.IsActive, frame)
            if ok and type(active)=="boolean" then
                if active then return false, "Tracked Buff present" end
                readable = true
            end
        end
    end
    if readable then return true, "Tracked Buff missing" end
    return false, "Buff unavailable: add Crash Lightning to Tracked Buffs"
end
function addon:ReadEnchant(slot)
    local item, itemOK = self:SafeCall(GetInventoryItemID, "player", slot)
    if not itemOK then return nil end
    if not item then return false end -- No equipped item: no imbue reminder.
    if C_PaperDollInfo and C_PaperDollInfo.GetTemporaryEnchantmentInfo then
        local enchant, ok = self:SafeCall(C_PaperDollInfo.GetTemporaryEnchantmentInfo, slot)
        if not ok then return nil end
        return enchant == nil
    end
    -- Compatibility with clients preceding the per-slot API.
    if GetWeaponEnchantInfo then
        local ok, main, _, _, _, off = pcall(GetWeaponEnchantInfo)
        if not ok then return nil end
        local value
        if slot == 16 then value = main else value = off end
        if self:IsSecret(value) then return nil end
        return not value
    end
    return nil
end
function addon:ReadProc(info)
    for _, id in ipairs(info.spells) do
        local value, ok = self:SafeCall(C_SpellActivationOverlay and C_SpellActivationOverlay.IsSpellOverlayed, id)
        if ok and type(value) == "boolean" then self.overlay[id] = value end
        if self.overlay[id] then return true, "Blizzard proc" end
    end
    local aura, readable = self:ReadAura(info.aura)
    if aura then return true, "Player aura" end
    return false, readable and "Inactive" or "No readable proc"
end
function addon:ReadCooldown(info)
    local spellID
    for _,id in ipairs(info.spells) do if self.known[id] then spellID=id;break end end
    if not spellID then return false,"Talent / spell not learned" end
    if info.requiresTotemSlot then
        if type(GetTotemInfo)~="function" then return false,"Totem state unavailable" end
        local ok,present=pcall(GetTotemInfo,info.requiresTotemSlot)
        present=self:Public(present,"boolean")
        if not ok or present==nil then return false,"Totem state unavailable" end
        if not present then return false,"Requires active Fire totem" end
    end
    local cooldown,ok=self:SafeCall(C_Spell and C_Spell.GetSpellCooldown,spellID)
    if not ok or type(cooldown)~="table" then return false,"Cooldown unavailable" end
    local start=self:Public(cooldown.startTime,"number")
    local duration=self:Public(cooldown.duration,"number")
    local enabled=self:Public(cooldown.isEnabled,"boolean")
    if enabled==false then return false,"Spell disabled" end
    if start==nil or duration==nil then return false,"Cooldown restricted" end
    -- Ignore the normal global cooldown so readiness does not flicker after
    -- casting another spell.
    local ready=duration<=1.6 or start+duration<=GetTime()
    return ready,ready and "Ready" or "On cooldown"
end
function addon:HasKnownSpell(info)
    for _,id in ipairs(info.spells) do if self.known[id] then return true end end
    return false
end
function addon:RefreshState()
    if not ShamanAssistForeverDB then return end
    local usable = ShamanAssistForeverDB.enabled and self.isSupported
    local dead = UnitIsDeadOrGhost("player")
    local mounted = IsMounted()
    usable = usable and not dead and not mounted
    for _, key in ipairs(self.order) do
        local info, state, settings = self.info[key], self.states[key], ShamanAssistForeverDB.alerts[key]
        state.active, state.count, state.aura = false, nil, nil
        state.durationObject, state.expiration, state.totalDuration = nil, nil, nil
        state.status = not self:IsCurrentAlert(key) and "Inactive specialization" or "Disabled"
        if usable and self:IsCurrentAlert(key) and settings.enabled then
            if info.kind == "stacks" then
                local aura, readable = self:ReadAura(info.aura)
                state.aura = aura
                if aura then state.count = self:Public(aura.applications, "number")
                elseif readable then state.count = 0 end
                state.active = state.count ~= nil and state.count >= settings.threshold
                state.status = state.count ~= nil and "Player aura" or "Stack count unavailable"
            elseif info.kind == "proc" then
                state.active, state.status = self:ReadProc(info)
            elseif info.kind == "activeBuff" then
                self:ReadBuffTracker(key, state)
            elseif info.kind == "cooldown" then
                state.active,state.status=self:ReadCooldown(info)
            elseif info.kind == "buff" then
                if false then
                    state.active, state.status = self:ReadCrashLightningMissing()
                    state.active = self.known[info.spells[1]] and state.active or false
                else
                    local aura, readable = self:ReadAura(info.aura)
                    state.active = self:HasKnownSpell(info) and readable and not aura or false
                    state.status = aura and "Present" or (readable and "Missing" or "Buff state unavailable")
                end
            elseif info.kind == "enchant" then
                local missing = self:ReadEnchant(info.slot)
                state.active = self:HasKnownSpell(info) and missing == true or false
                state.status = missing == nil and "Imbue state unavailable" or (missing and "Missing" or "Present / no weapon")
            end
            if settings.combatOnly and not InCombatLockdown() then state.active = false end
        end
        state.visible = usable and self:IsCurrentAlert(key) and settings.enabled and (not settings.combatOnly or InCombatLockdown()) or false
        self:RenderAlert(key)
    end
    if self.UpdateExternalGlows then self:UpdateExternalGlows() end
end
function addon:ApplySettings()
    if not ShamanAssistForeverDB then return end
    if self.ApplyDisplaySettings then self:ApplyDisplaySettings() end
    self:RefreshState()
    if self.RequestScan then self:RequestScan() end
end
function addon:TestAlert(key)
    if self.layoutEditing then return end
    if not self.isSupported or (key and not self:IsSelectedAlert(key)) then return end
    self.testKey = key or "all"
    self.testStartedAt = GetTime()
    self.testEndsAt = self.testStartedAt + (self.testKey == "all" and 20 or 6)
    self.testGeneration = (self.testGeneration or 0) + 1
    local generation = self.testGeneration
    self:RefreshState()
    C_Timer.After(self.testKey == "all" and 20 or 6, function()
        if self.testGeneration == generation then self:StopTest() end
    end)
end
function addon:StopTest()
    if self.layoutEditing then return end
    self.testKey = nil
    self.testGeneration = (self.testGeneration or 0) + 1
    self:RefreshState()
end
function addon:IsTesting(key) return self:IsSelectedAlert(key) and (self.testKey == "all" or self.testKey == key) end
function addon:StartLayoutEdit()
    if InCombatLockdown() or self.layoutEditing or not self.isSupported then return end
    if self.settingsWindow then self.settingsWindow:Hide() end
    self.layoutSnapshot=CopyTable(ShamanAssistForeverDB.alerts)
    self.layoutWasLocked=ShamanAssistForeverDB.locked
    self.layoutEditing=true
    ShamanAssistForeverDB.locked=false
    self.testGeneration=(self.testGeneration or 0)+1
    self.testKey="all";self.testStartedAt=GetTime();self.testEndsAt=GetTime()+20
    self:ApplySettings()
    self.layoutToolbar:Show()
end
function addon:FinishLayoutEdit(save)
    if not self.layoutEditing then return end
    for _,key in ipairs(self.order) do
        local d=self.displays[key]
        for _,f in ipairs({d.icon,d.text,d.timeline}) do f:StopMovingOrSizing() end
        if not save then
            for _,field in ipairs({"point","textPoint","timelinePoint"}) do
                ShamanAssistForeverDB.alerts[key][field]=CopyTable(self.layoutSnapshot[key][field])
            end
        end
    end
    self.layoutEditing=false;self.layoutSnapshot=nil
    ShamanAssistForeverDB.locked=save or self.layoutWasLocked
    self.layoutToolbar:Hide();self:StopTest();self:ApplySettings()
end
function addon:ResetPositions(key)
    for _, name in ipairs(self.order) do
        if (not key and self:IsSelectedAlert(name)) or key == name then
            ShamanAssistForeverDB.alerts[name].point = CopyTable(self.defaults.alerts[name].point)
            ShamanAssistForeverDB.alerts[name].textPoint = CopyTable(self.defaults.alerts[name].textPoint)
            ShamanAssistForeverDB.alerts[name].timelinePoint = CopyTable(self.defaults.alerts[name].timelinePoint)
        end
    end
    self:ApplySettings()
end
function addon:PrintStatus()
    print("|cff4da3ffShaman Assist Forever " .. self.version .. "|r - " .. self.specName)
    for _, key in ipairs(self.order) do
        local s = self.states[key]
        print(self.info[key].name .. ": " .. s.status .. (s.count ~= nil and (" (" .. s.count .. ")") or ""))
    end
end

local events = CreateFrame("Frame")
for _, event in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", 
    "PLAYER_TALENT_UPDATE", "SPELLS_CHANGED", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_DEAD", "PLAYER_ALIVE",
    "PLAYER_UNGHOST", "PLAYER_TOTEM_UPDATE", "TRAIT_CONFIG_UPDATED", "PLAYER_MOUNT_DISPLAY_CHANGED", "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW", "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" }) do pcall(events.RegisterEvent,events,event) end
events:RegisterUnitEvent("UNIT_AURA", "player")
events:RegisterUnitEvent("UNIT_INVENTORY_CHANGED", "player")
events:SetScript("OnEvent", function(_, event, arg)
    if event == "ADDON_LOADED" then
        if arg == addonName then addon:InitializeDB() end
        return
    end
    if not ShamanAssistForeverDB then addon:InitializeDB() end
    if event == "PLAYER_LOGIN" then
        addon:UpdateSpec(); addon:CreateDisplays(); addon:ApplySettings(); addon:RegisterSettings()
        -- Lightweight upkeep refresh outside combat; no repeated frame scans.
        C_Timer.NewTicker(3, function()
            if addon.isSupported and not InCombatLockdown() and ShamanAssistForeverDB.enabled then addon:RefreshState() end
        end)
        return
    end
    if not addon.displays then return end
    if event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" or event == "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then
        arg = addon:Public(arg, "number")
        if not arg then return end
        addon.overlay[arg] = event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW"
    elseif event == "PLAYER_TALENT_UPDATE" or event == "TRAIT_CONFIG_UPDATED" or event == "SPELLS_CHANGED"
        or event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_REGEN_ENABLED" then
        addon.overlay = {}
        addon:UpdateSpec()
        if addon.RequestScan then addon:RequestScan() end
    elseif event == "PLAYER_REGEN_DISABLED" then
        addon:FinishLayoutEdit(false)
        addon.testKey = nil
        if addon.settingsWindow then addon.settingsWindow:Hide() end
    end
    addon:RefreshState()
end)

SLASH_SHAMANASSISTFOREVER1 = "/shaf"
SLASH_SHAMANASSISTFOREVER2 = "/shaforever"
SlashCmdList.SHAMANASSISTFOREVER = function(message)
    local command = (message or ""):lower():match("^%s*(%S*)")
    if command == "test" then addon:TestAlert()
    elseif command == "stop" then addon:StopTest()
    elseif command == "status" then addon:PrintStatus()
    elseif command == "rescan" then addon:RequestScan()
    elseif command == "unlock" then ShamanAssistForeverDB.locked=false; addon:ApplySettings(); addon:TestAlert()
    elseif command == "lock" then ShamanAssistForeverDB.locked=true; addon:StopTest(); addon:ApplySettings()
    else addon:OpenStandaloneSettings() end
end
